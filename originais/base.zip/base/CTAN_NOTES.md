The release files are signed using a detached signature.  You can obtain the
signature from the GitHub release page

    https://github.com/pgf-tikz/pgf/releases/download/3.1.11a/pgf_3.1.11a.ctan.flatdir.zip.sig
