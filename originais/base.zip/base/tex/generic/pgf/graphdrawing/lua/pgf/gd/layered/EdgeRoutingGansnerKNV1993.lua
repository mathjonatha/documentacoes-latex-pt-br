-- Copyright 2011 by Jannis Pohlmann
--
-- This file may be distributed and/or modified
--
-- 1. under the LaTeX Project Public License and/or
-- 2. under the GNU Public License
--
-- See the file doc/generic/pgf/licenses/LICENSE for more information

-- @release $Header$



local EdgeRoutingGansnerKNV1993 = {}


function EdgeRoutingGansnerKNV1993:run()
end


-- done
return EdgeRoutingGansnerKNV1993